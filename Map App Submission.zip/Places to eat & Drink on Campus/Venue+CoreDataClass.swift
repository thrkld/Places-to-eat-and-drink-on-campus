//
//  Venue+CoreDataClass.swift
//  Places to eat & Drink on Campus
//
//  Created by James Thirkeld on 01/12/2024.
//
//

import Foundation
import CoreData

@objc(Venue)
public class Venue: NSManagedObject {

}
